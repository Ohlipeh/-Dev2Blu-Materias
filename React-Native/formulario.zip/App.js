import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView } from 'react-native';

export default function App() {
  // Estados para armazenar cada campo
  const [cpf, setCpf] = useState('');
  const [nome, setNome] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [email, setEmail] = useState('');

  // Função para checar se o campo está vazio
  const campoVazio = (valor) => valor.trim() === '';

  // Checa se todos os campos estão preenchidos
  const formularioValido = !campoVazio(cpf) && !campoVazio(nome) && !campoVazio(dataNascimento) && !campoVazio(email);

  // Função chamada ao clicar em Salvar
  const salvarFormulario = () => {
    alert(`Dados salvos:\nCPF: ${cpf}\nNome: ${nome}\nData Nascimento: ${dataNascimento}\nEmail: ${email}`);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* CPF */}
      <Text style={styles.label}>CPF:</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu CPF"
        value={cpf}
        onChangeText={setCpf}
        keyboardType="numeric"
      />
      {campoVazio(cpf) && <Text style={styles.errorText}>* Campo obrigatório</Text>}

      {/* Nome */}
      <Text style={styles.label}>Nome:</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu nome"
        value={nome}
        onChangeText={setNome}
      />
      {campoVazio(nome) && <Text style={styles.errorText}>* Campo obrigatório</Text>}

      {/* Data de Nascimento */}
      <Text style={styles.label}>Data de Nascimento:</Text>
      <TextInput
        style={styles.input}
        placeholder="DD/MM/AAAA"
        value={dataNascimento}
        onChangeText={setDataNascimento}
      />
      {campoVazio(dataNascimento) && <Text style={styles.errorText}>* Campo obrigatório</Text>}

      {/* Email */}
      <Text style={styles.label}>Email:</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      {campoVazio(email) && <Text style={styles.errorText}>* Campo obrigatório</Text>}

      {/* Botão Salvar */}
      <View style={styles.buttonArea}>
        <Button
          title="Salvar"
          onPress={salvarFormulario}
          disabled={!formularioValido} // habilita somente quando todos campos preenchidos
        />
      </View>
    </ScrollView>
  );
}

// Estilos isolados
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,             // permite scroll se necessário
    justifyContent: 'center',
    alignItems: 'stretch',   // ocupar largura disponível
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  input: {
    height: 48,
    borderWidth: 1,
    borderColor: '#aaa',
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    marginBottom: 6, // espaço entre input e mensagem de erro
    backgroundColor: '#fff',
  },
  errorText: {
    color: 'red',
    fontWeight: 'bold',
    fontSize: 12,
    marginBottom: 10, // espaço antes do próximo label
  },
  buttonArea: {
    marginTop: 16,
  },
});
