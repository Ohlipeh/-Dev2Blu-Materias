import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  itemContainer: {
    flexDirection: 'row',        // horizontal: imagem + info
    alignItems: 'center',        // centraliza verticalmente
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    elevation: 3,                // sombra Android
  },
  animalImage: {
    width: 80,
    height: 80,
    borderRadius: 40,            // imagem circular
    marginRight: 16,
  },
  animalName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  animalDetails: {
    fontSize: 16,
    color: '#666',
    marginTop: 8,
  },
  button: {
    marginTop: 16,
  },
});
