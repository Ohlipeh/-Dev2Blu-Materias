import React from 'react';
import { View, Text, Image, Button, ScrollView } from 'react-native';
import { styles } from './styles';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Criando o Stack Navigator
const Stack = createNativeStackNavigator();

// Dados dos animais com imagens locais
const animals = [
  { id: 1, name: 'Leão', age: 5, description: 'O rei da selva', image: require('./assets/leao_peq.png') },
  { id: 2, name: 'Elefante', age: 8, description: 'O maior animal terrestre', image: require('./assets/elefante_peq.png') },
  { id: 3, name: 'Girafa', age: 4, description: 'O pescoço mais longo', image: require('./assets/girafa_peq.png') },
  { id: 4, name: 'Tigre', age: 6, description: 'Predador ágil e forte', image: require('./assets/tigre_peq.png') },
];

// Tela principal: lista de animais
function HomeScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      {animals.map((animal) => (
        <View key={animal.id} style={styles.itemContainer}>
          {/* Imagem do animal */}
          <Image source={animal.image} style={styles.animalImage} />

          {/* Nome e botão */}
          <View style={{ flex: 1 }}>
            <Text style={styles.animalName}>{animal.name}</Text>
            <Button
              title="Ver Detalhes"
              onPress={() => navigation.navigate('Details', { animal })}
            />
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

// Tela de detalhes do animal
function DetailsScreen({ route }) {
  // Recebe o animal via parâmetros
  const { animal } = route.params;

  return (
    <View style={styles.container}>
      <Image source={animal.image} style={styles.animalImage} />
      <Text style={styles.animalName}>{animal.name}</Text>
      <Text style={styles.animalDetails}>Idade: {animal.age} anos</Text>
      <Text style={styles.animalDetails}>Descrição: {animal.description}</Text>
    </View>
  );
}

// Componente principal
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Galeria de Animais' }} />
        <Stack.Screen name="Details" component={DetailsScreen} options={{ title: 'Detalhes do Animal' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
