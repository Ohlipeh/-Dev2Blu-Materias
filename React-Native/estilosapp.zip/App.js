import React from 'react';
import { View, Text, Image, Button, ScrollView, Alert } from 'react-native';
import { styles } from './styles';

// Lista de animais
const animals = [
  { id: 1, name: 'Leão', age: 5, description: 'O rei da selva', image: require('./assets/leao_peq.png') },
  { id: 2, name: 'Elefante', age: 8, description: 'O maior animal terrestre', image: require('./assets/elefante_peq.png') },
  { id: 3, name: 'Girafa', age: 4, description: 'O pescoço mais longo', image: require('./assets/girafa_peq.png') },
  { id: 4, name: 'Tigre', age: 6, description: 'Predador ágil e forte', image: require('./assets/tigre_peq.png') },
];

export default function App() {
  // Função para mostrar alerta ao clicar no botão
  const handlePress = (animal) => {
    Alert.alert(`${animal.name}`, `Idade: ${animal.age} anos\nDescrição: ${animal.description}`);
  };

  return (
    <ScrollView style={styles.container}>
      {animals.map((animal) => (
        <View key={animal.id} style={styles.card}>
          {/* Imagem do animal */}
          <Image source={animal.image} style={styles.animalImage} />

          {/* Informações do animal */}
          <View style={styles.animalInfo}>
            <Text style={styles.animalName}>{animal.name}</Text>
            <Text style={styles.animalDetails}>Idade: {animal.age} anos</Text>
            <Text style={styles.animalDetails}>{animal.description}</Text>

            {/* Botão de ação */}
            <View style={styles.buttonArea}>
              <Button title="Ver Detalhes" onPress={() => handlePress(animal)} />
            </View>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

