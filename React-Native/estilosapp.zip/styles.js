import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f2f2f2',
  },
  card: {
    flexDirection: 'row',          // Imagem + conteúdo lado a lado
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    padding: 12,
    alignItems: 'center',          // centraliza verticalmente
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,                  // sombra android
  },
  animalImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 12,
  },
  animalInfo: {
    flex: 1,
  },
  animalName: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  animalDetails: {
    fontSize: 14,
    color: '#555',
    marginBottom: 4,
  },
  buttonArea: {
    marginTop: 6,
    alignSelf: 'flex-start',      // botão alinhado à esquerda
  },
});

